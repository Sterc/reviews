<?php

/**
 * Reviews
 *
 * Copyright 2018 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/reviewssnippets.class.php';

class ReviewsSnippetReviews extends ReviewsSnippets
{
    /**
     * @access public.
     * @var Array.
     */
    public $properties = [
        'reviews'               => '',
        'limit'                 => 0,
        'where'                 => '{"active": "1"}',
        'sortby'                => '{"createdon": "DESC"}',
        'tpl'                   => '@FILE elements/chunks/item.chunk.tpl',
        'tplWrapper'            => '@FILE elements/chunks/wrapper.chunk.tpl',
        'tplWrapperEmpty'       => '',
        'usePdoTools'           => false,
        'usePdoElementsPath'    => false
    ];

    /**
     * @access public.
     * @param Array $properties.
     * @return String.
     */
    public function run(array $properties = [])
    {
        $this->setProperties($properties);

        $output = [];

        $resourceId = $this->getProperty('id', $this->modx->resource->get('id'));
        $reviewIds  = array_filter(explode(',', $this->getProperty('reviews')));
        $where      = json_decode($this->getProperty('where'), true);
        $sortby     = json_decode($this->getProperty('sortby'), true);
        $limit      = (int) $this->getProperty('limit');

        list($minRating, $maxRating) = explode('||', $this->config['ratings']);

        $criteria = $this->modx->newQuery('ReviewsReview');

        if ($where) {
            $criteria->where($where);
        }

        if (count($reviewIds) >= 1) {
            $criteria->where([
                'id:IN' => $reviewIds
            ]);
        } else {
            if (!empty($resourceId)) {
                $criteria->where([
                    'resource_id' => $resourceId
                ]);
            }
        }

        if ($sortby) {
            foreach ((array) $sortby as $key => $value) {
                if (in_array($value, ['RAND', 'RAND()'], true)) {
                    $criteria->sortby('RAND()');
                } else {
                    $criteria->sortby($key, $value);
                }
            }
        }

        if ($limit > 1) {
            $criteria->limit($limit);
        }

        $idx            = 1;
        $rating         = 0;
        $totalRating    = 0;
        $totalRatings   = $this->modx->getCount('ReviewsReview', $criteria);
        $stats          = [];
        $worstRating    = 0;
        $bestRating     = 0;

        for ($i = (int) $minRating; $i <= (int) $maxRating; $i++) {
            $stats[$i] = 0;
        }

        foreach ($this->modx->getCollection('ReviewsReview', $criteria) as $review) {
            $stats[$review->get('rating')]++;
            $totalRating += (int) $review->get('rating');

            $output[] = $this->getChunk($this->getProperty('tpl'), array_merge($review->toArray(), [
                'idx'       => $idx,
                'minRating' => $minRating,
                'maxRating' => $maxRating,
                'total'     => $totalRatings,
                'content'   => $review->getContent()
            ]));

            if ((int) $review->get('rating') < $worstRating) {
                $worstRating = (int) $review->get('rating');
            } else if ((int) $review->get('rating') > $bestRating) {
                $bestRating = (int) $review->get('rating');
            }

            $idx++;
        }

        if ($totalRating >= 1 && $totalRatings >= 1) {
            $rating = round((int) ($totalRating / $totalRatings));
        }

        if (!empty($output)) {
            $tplWrapper = $this->getProperty('tplWrapper');

            if (!empty($tplWrapper)) {
                return $this->getChunk($tplWrapper, [
                    'output'        => implode(PHP_EOL, $output),
                    'rating'        => $rating,
                    'minRating'     => $minRating,
                    'maxRating'     => $maxRating,
                    'worstRating'   => $worstRating,
                    'bestRating'    => $bestRating,
                    'stats'         => $stats,
                    'total'         => $totalRatings
                ]);
            }

            return implode(PHP_EOL, $output);
        }

        $tplWrapperEmpty = $this->getProperty('tplWrapperEmpty');

        if (!empty($tplWrapperEmpty)) {
            return $this->getChunk($tplWrapperEmpty);
        }

        return '';
    }
}
