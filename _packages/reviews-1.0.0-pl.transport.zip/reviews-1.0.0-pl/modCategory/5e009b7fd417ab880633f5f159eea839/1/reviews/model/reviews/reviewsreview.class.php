<?php

/**
 * Reviews
 *
 * Copyright 2018 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

class ReviewsReview extends xPDOSimpleObject
{
    /**
     * @access public.
     * @return String.
     */
    public function getContent()
    {
        $content = $this->get('content');

        if (!empty($content)) {
            if (preg_match('/^<(.*?)>/si', $content)) {
                if (preg_match('/^<(i|em|b|strong|a)(.*?)>/si', $content)) {
                    return '<p>' . $content . '</p>';
                }
            } else {
                return '<p>' . $content . '</p>';
            }
        }

        return $content;
    }
}
