--------------------
Snippet: Reviews
--------------------
Author: Sterc <modx@sterc.nl>

A simple reviews solution for MODx Revolution.

Official Documentation:
https://docs.modx.com/extras/revo/reviews