<?php

/**
 * Reviews
 *
 * Copyright 2018 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/reviewsreviewrating.class.php';

class ReviewsReviewRating_mysql extends ReviewsReviewRating
{
}
