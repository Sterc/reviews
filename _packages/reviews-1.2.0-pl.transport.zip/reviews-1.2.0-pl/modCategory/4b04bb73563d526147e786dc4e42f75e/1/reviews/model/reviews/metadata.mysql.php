<?php

/**
 * Reviews
 *
 * Copyright 2018 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'ReviewsReview',
        'ReviewsReviewRating',
        'ReviewsRating'
    ]
];
