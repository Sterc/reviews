<?php

/**
 * Reviews
 *
 * Copyright 2018 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

$_lang['rating_reviews.default']                        = 'Standaard';
$_lang['rating_reviews.craftsmanship']                  = 'Vakmanschap';
$_lang['rating_reviews.speed']                          = 'Snelheid';
$_lang['rating_reviews.customer_service']               = 'Klantvriendelijkheid';
$_lang['rating_reviews.service']                        = 'Service';
