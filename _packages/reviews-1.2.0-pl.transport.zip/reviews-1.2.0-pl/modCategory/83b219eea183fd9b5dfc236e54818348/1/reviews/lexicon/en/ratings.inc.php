<?php

/**
 * Reviews
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

$_lang['rating_reviews.default']                        = 'Default';
$_lang['rating_reviews.craftsmanship']                  = 'Craftsmanship';
$_lang['rating_reviews.speed']                          = 'Speed';
$_lang['rating_reviews.customer_service']               = 'Customer service';
$_lang['rating_reviews.service']                        = 'Service';
