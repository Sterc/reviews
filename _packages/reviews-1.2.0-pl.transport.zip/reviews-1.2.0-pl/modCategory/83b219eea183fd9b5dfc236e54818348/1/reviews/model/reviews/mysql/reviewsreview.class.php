<?php

/**
 * Reviews
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/reviewsreview.class.php';

class ReviewsReview_mysql extends ReviewsReview
{
}
