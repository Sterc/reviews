<?php

/**
 * Reviews
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        'ReviewsRating',
        'ReviewsReview',
        'ReviewsReviewRating'
    ]
];
